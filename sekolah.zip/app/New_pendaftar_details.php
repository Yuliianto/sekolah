<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class New_pendaftar_details extends Model
{
    //
}
