<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class New_pendaftares extends Model
{
    //
}
